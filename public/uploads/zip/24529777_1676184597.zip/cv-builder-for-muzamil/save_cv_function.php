function cv_builder_page()
    {
        if($this->input->post())
        {
            $res = [];
            $res['status'] = 1;
            // $res['validationErrors'] = '';
            // $res['msg'] = '';
            // $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            // $this->form_validation->set_rules('password', 'Password', 'required');
            // if ($this->form_validation->run() === FALSE) {
            //     $res['validationErrors'] = validation_errors();
            // }
            // else
            // {
                $post  = $this->input->post();
                // pr($post);
                $token = explode('_', doDecode($post['authToken']));
                $mem_id = $token[1];
                
                $cv_id = $this->master->save('mem_cv', ['mem_id'=> $mem_id]); 
                foreach($post['e_university_name'] as $index => $uni):
                    $education = [
                        'cv_id'=> $cv_id,
                        'university_name' => trim($uni),
                        'course_name'     => trim($post['e_course_name'][$index]),
                        'detail'          => trim($post['e_detail'][$index]),
                        'year_start'      => trim($post['e_year_start'][$index]),
                        'year_end'        => trim($post['e_year_end'][$index])
                    ];

                    $this->master->save('cv_educational', $education);
                endforeach;

                foreach($post['pe_company_name'] as $index => $pro):
                    $professional = [
                        'cv_id'=> $cv_id,
                        'company_name'    => trim($pro),
                        'job_title'       => trim($post['pe_job_title'][$index]),
                        'detail'          => trim($post['pe_detail'][$index]),
                        'year_start'      => trim($post['pe_year_start'][$index]),
                        'year_end'        => trim($post['pe_year_end'][$index])
                    ];
                    $this->master->save('cv_professional_experience', $professional);
                endforeach;

                foreach($post['s_it_skill'] as $index => $skill):
                    $it_skillsArr = [
                        'cv_id'           => $cv_id,
                        'it_skill_id'     => trim($skill),
                        'type'            => 'it_skill',
                    ];

                    $this->master->save('cv_others', $it_skillsArr);
                endforeach;

                foreach($post['s_language'] as $index => $language):
                    $languageArr = [
                        'cv_id'           => $cv_id,
                        'language_id'     => trim($language),
                        'type'            => 'language',
                    ];

                    $this->master->save('cv_others', $languageArr);
                endforeach;

                foreach($post['v_volunteer'] as $index => $volunteer):
                    $volunteerArr = [
                        'cv_id'           => $cv_id,
                        'volunteer'        => trim($volunteer),
                        'type'            => 'volunteer',
                    ];

                    $this->master->save('cv_others', $volunteerArr);
                endforeach;

                foreach($post['i_interest'] as $index => $interst):
                    $interstArr = [
                        'cv_id'=> $cv_id,
                        'interest'        => trim($interst),
                        'type'            => 'interest',
                    ];

                    $this->master->save('cv_others', $interstArr);
                endforeach;

                foreach($post['r_person_name'] as $index => $pref):
                    $reference = [
                        'cv_id'                 => $cv_id,
                        'person_name'           => trim($pref),
                        'job_title_and_company' => trim($post['r_job_title_and_company'][$index]),
                        'year_start'            => trim($post['r_year_start'][$index]),
                        'year_end'              => trim($post['r_year_end'][$index])
                    ];

                    $this->master->save('cv_references', $reference);
                endforeach;
            // }

            http_response_code(200);
            echo json_encode($res);
        }
        else
        {
            http_response_code(404);
        }
        exit;
    }