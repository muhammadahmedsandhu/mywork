import React, { useEffect, useState } from "react";

import { fetchCvBuilder, saveCV } from "../../../states/actions/fetchCvBuilder";
import { useSelector, useDispatch } from "react-redux";
import useDocumentTitle from "../../../hooks/useDocumentTitle";
import LoadingScreen from "../../common/LoadingScreen";
import Text from "../../common/Text";
import FormProcessingSpinner from "../../common/FormProcessingSpinner";
import { ToastContainer } from "react-toastify";

import { useForm } from "react-hook-form";

const CvBuilder = () => {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.fetchCvBuilder.content);
  const isLoading = useSelector((state) => state.fetchCvBuilder.isLoading);
  const isCvSubmitting = useSelector(
    (state) => state.fetchCvBuilder.isCvSubmitting
  );
  const cvAction = useSelector((state) => state.fetchCvBuilder.cvAction);
  const isSiteSettingsLoading = useSelector(
    (state) => state.fetchSiteSettings.isLoading
  );
  const memData = useSelector((state) => state.fetchSiteSettings.memData);
  const { content, sec2sLeft, languages, it_skills } = data;
  useEffect(() => {
    dispatch(fetchCvBuilder());
  }, []);

  const {
    register,
    formState: { errors },
    handleSubmit
  } = useForm();

  const EDUCATIONAL = {
    e_id: 0,
    e_university_name: "",
    e_course_name: "",
    e_year_start: "",
    e_year_end: "",
    e_detail: "",
    e_delete: false
  };
  const PROFESSIONAL_EXPERIENCE = {
    pe_id: 0,
    pe_company_name: "",
    pe_job_title: "",
    pe_year_start: "",
    pe_year_end: "",
    pe_detail: "",
    pe_delete: false
  };
  const REFERENCE = {
    r_id: 0,
    r_person_name: "",
    r_job_title_and_company: "",
    r_year_start: "",
    r_year_end: "",
    r_delete: false
  };
  const VOLUNTEER = {
    v_id: 0,
    v_volunteer: "",
    v_delete: false
  };
  const INTEREST = {
    i_id: 0,
    i_interest: "",
    i_delete: false
  };
  const SKILLS = {
    s_id: 0,
    s_language: "",
    s_it_skill: "",
    s_delete: false
  };

  const [educationalRows, setEducationalRows] = useState([EDUCATIONAL]);
  const [professionalExperienceRows, setProfessionalExperienceRows] = useState([
    PROFESSIONAL_EXPERIENCE
  ]);
  const [referenceRows, setReferenceRows] = useState([REFERENCE]);
  const [volunteerRows, setVolunteerRows] = useState([VOLUNTEER]);
  const [interestRows, setInterestRows] = useState([INTEREST]);
  const [skillsRows, setSkillsRows] = useState([SKILLS]);

  const appendEducationalVideo = (e) => {
    e.preventDefault();
    let rows = [...educationalRows];
    rows.push(EDUCATIONAL);
    setEducationalRows(rows);
  };
  const handleEducationalSectionChange = (e, index) => {
    let values = [...educationalRows];
    values[index][e.target.name] = e.target.value;
    setEducationalRows(values);
  };

  const appendProfessionalExperience = (e) => {
    e.preventDefault();
    let rows = [...professionalExperienceRows];
    rows.push(PROFESSIONAL_EXPERIENCE);
    setProfessionalExperienceRows(rows);
  };
  const handleProfessionalExperienceChange = (e, index) => {
    let values = [...professionalExperienceRows];
    values[index][e.target.name] = e.target.value;
    setProfessionalExperienceRows(values);
  };

  const appendReference = (e) => {
    e.preventDefault();
    let rows = [...referenceRows];
    rows.push(REFERENCE);
    setReferenceRows(rows);
  };
  const handleReferenceChange = (e, index) => {
    let values = [...referenceRows];
    values[index][e.target.name] = e.target.value;
    setReferenceRows(values);
  };

  const appendVolunteer = (e) => {
    e.preventDefault();
    let rows = [...volunteerRows];
    rows.push(VOLUNTEER);
    setVolunteerRows(rows);
  };
  const handleVolunteerChange = (e, index) => {
    let values = [...volunteerRows];
    values[index][e.target.name] = e.target.value;
    setVolunteerRows(values);
  };

  const appendInterest = (e) => {
    e.preventDefault();
    let rows = [...interestRows];
    rows.push(INTEREST);
    setInterestRows(rows);
  };
  const handleInterestChange = (e, index) => {
    let values = [...interestRows];
    values[index][e.target.name] = e.target.value;
    setInterestRows(values);
  };

  const appendSkills = (e) => {
    e.preventDefault();
    let rows = [...skillsRows];
    rows.push(SKILLS);
    setSkillsRows(rows);
  };
  const handleSkillsChange = (e, index) => {
    let values = [...skillsRows];
    values[index][e.target.name] = e.target.value;
    setSkillsRows(values);
  };

  const dataOfCV = () => {
    const cvData = {
      authToken: `${localStorage.getItem("authToken")}`,
      educational: educationalRows,
      professional: professionalExperienceRows,
      skills: skillsRows,
      volunteers: volunteerRows,
      interests: interestRows,
      references: referenceRows
    };
    return cvData;
  };

  // CV ACTIONS
  const handleSaveCV = (e) => {
    e.preventDefault();
    dispatch(saveCV(dataOfCV()));
  };

  const handleDownloadCV = (e) => {
    e.preventDefault();
    console.log("save Download CV");
  };

  const handleSubmitForReviewCV = (e) => {
    e.preventDefault();
    console.log("save Submit For Review CV");
  };

  const onSubmit = (data) => {
    console.log(data);
    let post = { ...data, authToken: `${localStorage.getItem("authToken")}` };
    dispatch(saveCV(post));
  };

  // PAGE TITLE
  useDocumentTitle(data.page_title);
  return (
    <>
      {isLoading || isSiteSettingsLoading ? (
        <LoadingScreen />
      ) : (
        <>
          <ToastContainer />
          <section className="cv_build">
            <div className="outer_cv">
              <div className="colL">
                <div className="inner">
                  <h4>
                    <Text string={content.banner_heading} />
                  </h4>
                  <p>
                    <Text string={content.banner_detail} />
                  </p>
                  <div className="gap_line" />
                  <div className="cv_type">
                    {sec2sLeft &&
                      sec2sLeft.map((sec) => (
                        <div className="inner_type">
                          <h5>
                            <Text string={sec.title} />
                          </h5>
                          <p>
                            <Text string={sec.detail} />
                          </p>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
              <div className="colR">
                <div className="cv_head">
                  <h4>Preview</h4>
                  <div className="btn_blk">
                    <button
                      className="site_btn green_btn"
                      form="save-cv-form"
                      type="submit"
                      disabled={isCvSubmitting}
                    >
                      <FormProcessingSpinner
                        isFormProcessing={cvAction === "save"}
                      />
                      Save
                    </button>
                    <button
                      className="site_btn stroke blank"
                      onClick={handleDownloadCV}
                      disabled={isCvSubmitting}
                    >
                      <FormProcessingSpinner
                        isFormProcessing={cvAction === "download"}
                      />
                      Download
                    </button>
                    <button
                      className="site_btn purple_btn"
                      onClick={handleSubmitForReviewCV}
                      disabled={isCvSubmitting}
                    >
                      <FormProcessingSpinner
                        isFormProcessing={cvAction === "submit_for_review"}
                      />
                      Submit for Review
                    </button>
                  </div>
                </div>
                <div className="cv_form">
                  <div className="main_intro text-center">
                    <h2 className="heading">{`${memData.mem_fname} ${memData.mem_lname}`}</h2>
                    <p>{`${memData.mem_email} | ${memData.mem_phone}`}</p>
                  </div>
                  <form id="save-cv-form" onSubmit={handleSubmit(onSubmit)}>
                    <div className="main_field_blk">
                      <div className="blk_out">
                        <div className="inner_field_blk">
                          <h4 className="heading">EDUCATION</h4>
                          {educationalRows.map((row, index) => (
                            <>
                              <div className="field_flex" key={index}>
                                <div className="col_sm_9">
                                  <div className="form_blk_new">
                                    <input
                                      type="text"
                                      placeholder="University name"
                                      className="dim_field bold_text"
                                      {...register(
                                        `e_university_name[${index}]`,
                                        {
                                          required:
                                            "University name is required."
                                        }
                                      )}
                                    />
                                    <span className="validation-error">
                                      {
                                        errors.e_university_name?.[index]
                                          ?.message
                                      }
                                    </span>
                                  </div>
                                </div>
                                <div className="col_sm_3 flex">
                                  <div className="form_blk_new">
                                    <input
                                      type="text"
                                      placeholder="YYYY"
                                      className="dim_field bold_text year_field"
                                      {...register(`e_year_start[${index}]`, {
                                        required:
                                          "Duration start year is required."
                                      })}
                                    />
                                    <span className="validation-error">
                                      {errors.e_year_start?.[index]?.message}
                                    </span>
                                  </div>
                                  <span>-</span>
                                  <div className="form_blk_new">
                                    <input
                                      type="text"
                                      placeholder="YYYY"
                                      className="dim_field bold_text year_field"
                                      {...register(`e_year_end[${index}]`, {
                                        required:
                                          "Duration end year is required."
                                      })}
                                    />
                                    <span className="validation-error">
                                      {errors.e_year_end?.[index]?.message}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className="form_blk_new">
                                <input
                                  type="text"
                                  placeholder="Course name"
                                  className="dim_field bold_text"
                                  {...register(`e_course_name[${index}]`, {
                                    required: "Course Name is required."
                                  })}
                                />
                                <span className="validation-error">
                                  {errors.e_course_name?.[index]?.message}
                                </span>
                              </div>
                              <div className="form_blk_new">
                                <textarea
                                  className="dim_field light_text"
                                  placeholder="Please describe about your course details"
                                  {...register(`e_detail[${index}]`, {
                                    required: "Detail is required."
                                  })}
                                />
                                <span className="validation-error">
                                  {errors.e_detail?.[index]?.message}
                                </span>
                              </div>
                            </>
                          ))}
                        </div>

                        <div className="add_more_field_btn">
                          <div className="btn_blk">
                            <button
                              className="site_btn small round light"
                              onClick={appendEducationalVideo}
                            >
                              + Add Education
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="blk_out">
                        <div className="inner_field_blk">
                          <h4 className="heading">Professional experince</h4>
                          {professionalExperienceRows &&
                            professionalExperienceRows.map((row, index) => (
                              <>
                                <div className="field_flex" key={index}>
                                  <div className="col_sm_9">
                                    <div className="form_blk_new">
                                      <input
                                        type="text"
                                        placeholder="Company name"
                                        className="dim_field bold_text"
                                        {...register(
                                          `pe_company_name[${index}]`,
                                          {
                                            required:
                                              "Company Name is required."
                                          }
                                        )}
                                      />
                                      <span className="validation-error">
                                        {
                                          errors.pe_company_name?.[index]
                                            ?.message
                                        }
                                      </span>
                                    </div>
                                  </div>
                                  <div className="col_sm_3 flex">
                                    <div className="form_blk_new">
                                      <input
                                        type="text"
                                        placeholder="YYYY"
                                        className="dim_field bold_text year_field"
                                        {...register(
                                          `pe_year_start[${index}]`,
                                          {
                                            required:
                                              "Duration Year Start is required."
                                          }
                                        )}
                                      />
                                      <span className="validation-error">
                                        {errors.pe_year_start?.[index]?.message}
                                      </span>
                                    </div>
                                    <span>-</span>
                                    <div className="form_blk_new">
                                      <input
                                        type="text"
                                        placeholder="YYYY"
                                        className="dim_field bold_text year_field"
                                        {...register(`pe_year_end[${index}]`, {
                                          required:
                                            "Duration Year End is required."
                                        })}
                                      />
                                      <span className="validation-error">
                                        {errors.pe_year_end?.[index]?.message}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="form_blk_new">
                                  <input
                                    type="text"
                                    placeholder="Job title"
                                    className="dim_field bold_text"
                                    {...register(`pe_job_title[${index}]`, {
                                      required: "Job Title is required."
                                    })}
                                  />
                                  <span className="validation-error">
                                    {errors.pe_job_title?.[index]?.message}
                                  </span>
                                </div>
                                <div className="form_blk_new">
                                  <textarea
                                    className="dim_field light_text"
                                    placeholder="Please describe about your responsibilties and duties in this position "
                                    {...register(`pe_detail[${index}]`, {
                                      required: "Detail is required."
                                    })}
                                  />
                                  <span className="validation-error">
                                    {errors.pe_detail?.[index]?.message}
                                  </span>
                                </div>
                              </>
                            ))}
                        </div>
                        <div className="add_more_field_btn">
                          <div className="btn_blk">
                            <button
                              className="site_btn small round light"
                              onClick={appendProfessionalExperience}
                            >
                              + Add Experince
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="blk_out">
                        <div className="inner_field_blk">
                          <h4 className="heading">Skills</h4>
                          {skillsRows &&
                            skillsRows.map((row, index) => (
                              <>
                                <div
                                  className="form_blk_new gap_bot"
                                  key={index}
                                >
                                  <h6>Languages :</h6>
                                  <select
                                    className="input"
                                    {...register(`s_language[${index}]`, {
                                      required: "Language is required."
                                    })}
                                  >
                                    <option value="">Select</option>
                                    {languages &&
                                      languages.map((l) => (
                                        <option value={l.id}>{l.name}</option>
                                      ))}
                                  </select>
                                  <span className="validation-error">
                                    {errors.s_language?.[index]?.message}
                                  </span>
                                </div>
                                <div className="form_blk_new gap_bot">
                                  <h6>IT skills :</h6>
                                  <select
                                    className="input"
                                    {...register(`s_it_skill[${index}]`, {
                                      required: "It Skill is required."
                                    })}
                                  >
                                    <option value="">Select</option>
                                    {it_skills &&
                                      it_skills.map((s) => (
                                        <option value={s.id}>{s.name}</option>
                                      ))}
                                  </select>
                                  <span className="validation-error">
                                    {errors.s_it_skill?.[index]?.message}
                                  </span>
                                </div>
                              </>
                            ))}
                        </div>
                        <div className="add_more_field_btn">
                          <div className="btn_blk">
                            <button
                              className="site_btn small round light"
                              onClick={appendSkills}
                            >
                              + Add Skills
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="blk_out">
                        {volunteerRows &&
                          volunteerRows.map((row, index) => (
                            <>
                              <div className="inner_field_blk" key={index}>
                                <input
                                  type="text"
                                  placeholder="Volunteering :"
                                  className="dim_field bold_text"
                                  {...register(`v_volunteer[${index}]`, {
                                    required: "Volunteer is required."
                                  })}
                                />
                                <span className="validation-error">
                                  {errors.v_volunteer?.[index]?.message}
                                </span>
                              </div>
                            </>
                          ))}
                        <div className="add_more_field_btn">
                          <div className="btn_blk">
                            <button
                              className="site_btn small round light"
                              onClick={appendVolunteer}
                            >
                              + Add Volunteering{" "}
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="blk_out">
                        {interestRows &&
                          interestRows.map((row, index) => (
                            <>
                              <div className="inner_field_blk" key={index}>
                                <input
                                  type="text"
                                  placeholder="Interest :"
                                  className="dim_field bold_text"
                                  {...register(`i_interest[${index}]`, {
                                    required: "Interest is required."
                                  })}
                                />
                                <span className="validation-error">
                                  {errors.i_interest?.[index]?.message}
                                </span>
                              </div>
                            </>
                          ))}
                        <div className="add_more_field_btn">
                          <div className="btn_blk">
                            <button
                              className="site_btn small round light"
                              onClick={appendInterest}
                            >
                              + Add Interest
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="blk_out">
                        <div className="inner_field_blk">
                          <h4 className="heading">References </h4>
                          {referenceRows &&
                            referenceRows.map((row, index) => (
                              <>
                                <div className="field_flex" key={index}>
                                  <div className="col_sm_9">
                                    <div className="form_blk_new">
                                      <input
                                        type="text"
                                        placeholder="Person name"
                                        className="dim_field bold_text"
                                        {...register(
                                          `r_person_name[${index}]`,
                                          {
                                            required: "Person Name is required."
                                          }
                                        )}
                                      />
                                      <span className="validation-error">
                                        {errors.r_person_name?.[index]?.message}
                                      </span>
                                    </div>
                                  </div>
                                  <div className="col_sm_3 flex">
                                    <div className="form_blk_new">
                                      <input
                                        type="text"
                                        placeholder="YYYY"
                                        className="dim_field bold_text year_field"
                                        {...register(`r_year_start[${index}]`, {
                                          required:
                                            "Duration Year Start is required."
                                        })}
                                      />
                                      <span className="validation-error">
                                        {errors.r_year_start?.[index]?.message}
                                      </span>
                                    </div>
                                    <span>-</span>
                                    <div className="form_blk_new">
                                      <input
                                        type="text"
                                        placeholder="YYYY"
                                        className="dim_field bold_text year_field"
                                        {...register(`r_year_end[${index}]`, {
                                          required:
                                            "Duration Year End is required."
                                        })}
                                      />
                                      <span className="validation-error">
                                        {errors.r_year_end?.[index]?.message}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="form_blk_new">
                                  <textarea
                                    className="dim_field light_text"
                                    placeholder="Person’s job title and company"
                                    {...register(
                                      `r_job_title_and_company[${index}]`,
                                      {
                                        required:
                                          "Job Title And Company is required."
                                      }
                                    )}
                                  />
                                  <span className="validation-error">
                                    {
                                      errors.r_job_title_and_company?.[index]
                                        ?.message
                                    }
                                  </span>
                                </div>
                              </>
                            ))}
                        </div>
                        <div className="add_more_field_btn">
                          <div className="btn_blk">
                            <button
                              button="button"
                              className="site_btn small round light"
                              onClick={appendReference}
                            >
                              + Add Reference
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </section>
        </>
      )}
    </>
  );
};
export default CvBuilder;
