
// 2.Write a program in C++ to check whether a number is prime or not

#include <iostream>

using namespace std;

int main()
{
    int num,i;
    bool isPrime = true;

    cout << "Enter an integer number : ";
    cin >> num;

    if(num < 0)
    {
        cout << num << " Is not a positive number";
    }
    else
    {
        for(i=2;i<=num-1;i++)
        {
            if(num%i == 0)
            {
                isPrime = false;
                break;
            }
        }

        if(isPrime == true)
        {
            cout <<num <<" is a prime number";
        }
        else
        {
            cout <<num <<" is not a prime number";
        }
    }

    return 0;
}
