
#include <iostream>

using namespace std;

int main()
{
    int i,j;

    for(i=1;i<=5;i++)
    {
        cout <<"Multiplication table of " <<i <<"\n";

        for(j=1;j<=10;j++)
        {
            cout << i <<" * " << j << " = " << i*j << "\n";
        }

        cout << "\n\n";
    }
    return 0;
}
