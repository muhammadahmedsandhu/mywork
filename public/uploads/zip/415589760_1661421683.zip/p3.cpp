
/*
3. Write a program for grading :
if the percentage is above 90, assign grade A
if the percentage is above 75, assign grade B
if the percentage is above 65, assign grade C
*/

#include <iostream>

using namespace std;

int main()
{
    int grade;

    cout << "Enter your grade number : ";
    cin >> grade;

    if(grade >= 90)
    {
        cout << "Your grade is 'A'";
    }
    else if(grade >= 75)
    {
        cout << "Your grade is 'B'";
    }
    else if(grade >= 65)
    {
        cout << "Your grade is 'C'";
    }
    else
    {
        cout << "You are failed";
    }
    return 0;
}
