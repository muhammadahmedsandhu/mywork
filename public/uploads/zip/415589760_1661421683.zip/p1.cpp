
// 1.Write a C++ program to calculate factorial of a number.

#include <iostream>

using namespace std;

int main()
{
    int num,i,fact=1;

    cout << "Enter an integer : ";
    cin >> num;

    if(num > 0)
    {
        for(i=1;i<=num;i++)
        {
            fact = fact*i;
        }
        cout << "Factorial of " <<num << " is = " << fact;
    }
    else
    {
        cout << "Factorial does not exist\n";
    }

    return 0;
}
